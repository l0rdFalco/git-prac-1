refreshing my git knowledge using the 5 hour very useful tutorial
